public class Runner 
{
	public static void main (String args[])
	{
		Board UNO = new Board();
		UNO.launch();
	}
}