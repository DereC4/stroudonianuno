public class Card 
{
	private String color;// r 0 b 1 y 2 g 3 s
	private int val;
	public Card(String color, int val)
	{
		this.color=color;
		this.val=val;
	}
	public String getColor()
	{
		return color;
	}
	public int getVal()
	{
		return val;
	}
	public String toString()
	{
		return color + " " + val+ " ";
	}
}