import java.util.Scanner;

public class Board 
{
	private Player[]player;
	private Deck deck;
	private int turn;
	private boolean onward;
	public Board()
	{
		deck = new Deck();
		player = new Player[4];
		for (int i = 0; i < player.length; i ++)
			player[i]= new Player();
		init();
		dalos();
	}
	public void init()
	{
		deck.fill();
		deck.Shuffle();
	}
	public void dalos()
	{
		for (int i = 0; i < player.length; i++)
		{
			for (int c = 0; c < 7; c++)
			{
				player[i].addcard(deck.remove());
			}
		}
	}
	public void nextturn()
	{
		//continue turn
		if (onward)
		{
			if(turn != player.length-1)
				turn++;
			else 
				turn = 0;
		}
		//backward
		if (onward=false)
		{
			if(turn >= 0)
				turn--;
			else
				turn = player.length-1;
			
		}
	}
	public void checkCard()
	{
		//
	}
	public boolean canplay (Card ontop, Card c)
	{
		if(c.getColor().equals(ontop.getColor())||c.getVal()==ontop.getVal())
			return true;
		//13 wild 14 +4
		if(c.getVal()==13||c.getVal()==14)
			return true;
		return false;
	}
	public void launch() 
	{
		System.out.println("~~~~~~~~~~~~~~~~~~~UNO~~~~~~~~~~~~~~~~~~~");
		System.out.println("Player: " + turn);
		System.out.println("Cards \n"+player[turn].print());
		onward = true;
		if (canplay(deck.ontop(), deck.getcard(0)))
		{
			
		}
		nextturn();
	}
}