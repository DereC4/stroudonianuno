import javax.swing.*;
import java.io.IOException;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Event;

public class Graphics
{
	private JFrame jf;
	
	public Graphics()
	{
		init();
	}
	public void init()
	{
		jf = new JFrame("UNO");
		jf.setVisible(true);
		jf.setSize(300,400);  
		ImageIcon img = new ImageIcon("unocards/+4.png");  
		JButton b = new JButton("Play", img);    
		b.setBounds(5, 5, img.getIconHeight(),img.getIconWidth());   
		jf.add(b);
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);    
	}
}